-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE latin1_general_ci NOT NULL,
  `date_create` timestamp NOT NULL,
  `likes` smallint(6) NOT NULL,
  `dislikes` smallint(6) NOT NULL,
  `author` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `validated` tinyint(4) NOT NULL,
  `id_post` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`id_post`) REFERENCES `post` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `comment` (`id`, `content`, `date_create`, `likes`, `dislikes`, `author`, `validated`, `id_post`) VALUES
(3,	'Ceci est un commentaire très pertinent',	'2018-03-20 18:29:43',	0,	0,	'Son blase',	1,	1),
(4,	'Encore un autre commentaire',	'2018-03-22 18:00:38',	0,	0,	'Un autre',	0,	1),
(5,	'Un commentaire en l\'air',	'2018-03-22 20:50:31',	0,	0,	'C\'est l\'autre',	0,	10);

DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `validated` tinyint(4) NOT NULL,
  `date_create` timestamp NOT NULL,
  `id_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_type` (`id_type`),
  CONSTRAINT `member_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `member` (`id`, `login`, `password`, `validated`, `date_create`, `id_type`) VALUES
(1,	'root',	'root',	0,	'2018-03-19 23:00:00',	1),
(2,	'Visitor',	'OpenClassrooms',	0,	'2018-03-24 23:00:00',	2);

DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `lede` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `content` text COLLATE latin1_general_ci NOT NULL,
  `date_create` timestamp NOT NULL,
  `date_update` timestamp NOT NULL,
  `img` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_member` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_member` (`id_member`),
  CONSTRAINT `post_ibfk_2` FOREIGN KEY (`id_member`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `post` (`id`, `title`, `lede`, `content`, `date_create`, `date_update`, `img`, `id_member`) VALUES
(1,	'Un nouveau titre ici',	'Le lede est comme cela maintenant',	'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores quasi, voluptatem aliquam facilis repellendus, ad totam reiciendis neque atque, eveniet cupiditate ipsam magni provident corporis vel repellat alias obcaecati cumque.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur, adipisci dolores magnam eum! Voluptatibus quibusdam expedita voluptate esse repellat, totam autem fugiat aliquam ipsum praesentium! Consequatur totam cupiditate, explicabo sed.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa dolorum iusto sed repellendus reprehenderit cum eaque sequi ipsum odio vero. Dignissimos quasi, culpa suscipit temporibus nam rem voluptatem ipsa earum.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem eaque maxime repellat porro non, accusantium iure sit saepe quas laudantium eligendi voluptatum pariatur earum deleniti. Neque libero odit fugit blanditiis.\r\n',	'2018-03-14 12:45:30',	'2018-03-22 17:16:38',	'dev.jpg',	1),
(2,	'Titre ici',	'lede la',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ut sollicitudin enim, in vulputate elit. Aenean fringilla luctus nisl in tincidunt. In turpis quam, consequat fringilla nibh non, faucibus cursus nisl. Aliquam ac nulla id nunc euismod tempor nec ac quam. Nulla bibendum est id turpis luctus consectetur. Morbi non ex lacinia turpis eleifend porttitor. Nam vitae tristique tortor. Sed nec mauris nibh. Duis lobortis, leo sed varius semper, eros est elementum est, ut posuere magna purus nec orci. Quisque vel sem sit amet nulla aliquam volutpat vel a est. Morbi eget ex vel erat malesuada vestibulum.\r\n\r\nCras porttitor lacinia ex, vel egestas velit imperdiet non. Pellentesque eu cursus tellus. Integer tempus sapien vitae lorem ullamcorper pellentesque. Cras mollis urna id erat tempus semper. Quisque vel est turpis. Duis non convallis erat. In ultrices in nibh non euismod. Nam vitae ornare nisi. Sed ultrices neque vitae bibendum tincidunt. Vestibulum a mi leo. Sed ac erat at quam luctus pulvinar. Phasellus sed sollicitudin lorem.\r\n\r\nInteger fermentum vitae quam eget ultricies. Nullam pellentesque sem non feugiat ullamcorper. Aenean vestibulum consequat venenatis. Maecenas ipsum lectus, ullamcorper sit amet augue vel, volutpat eleifend turpis. Aliquam vitae ex ex. Fusce commodo risus quis arcu accumsan lobortis. Sed ac fermentum ante.\r\n\r\nCras euismod blandit odio suscipit euismod. Etiam placerat sed turpis bibendum varius. Cras ultrices, velit vel convallis sagittis, est nunc gravida urna, rhoncus dictum risus risus non est. Cras finibus sem semper, posuere justo ut, mattis tellus. Pellentesque suscipit mattis efficitur. Proin interdum eros eget nisl tincidunt, eu elementum magna malesuada. Suspendisse vulputate orci at purus malesuada, non volutpat leo cursus. Duis sit amet quam a est efficitur hendrerit.\r\n\r\nVivamus iaculis nulla a eros convallis posuere. Morbi aliquet turpis id purus luctus volutpat. Etiam ligula eros, ultrices consectetur ante et, interdum auctor enim. Duis tincidunt porttitor sapien eu euismod. Morbi sed nunc suscipit, elementum justo eu, porttitor tortor. In euismod ex vel risus porttitor sagittis. Ut ornare egestas rutrum. Nam tincidunt eros odio, eget tristique ex mattis et. Vestibulum laoreet ex ut diam rutrum mollis. Suspendisse potenti. Nullam lacinia feugiat venenatis. Proin iaculis libero quis neque hendrerit tempor ac at nunc. Suspendisse potenti. Praesent ullamcorper blandit leo scelerisque aliquam.',	'2018-03-14 12:41:14',	'2018-03-14 12:41:14',	'futur-internet.jpg',	1),
(3,	'Titre de l\'article est le suivant',	'Salut la compagnie',	'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta laborum rerum qui fugiat sint ipsum. Dolore possimus ut fugiat quibusdam, nam provident consequatur, dolorem obcaecati veniam facilis rerum distinctio repellendus.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, esse in, facere at totam exercitationem consequatur minus unde laboriosam officia tenetur magnam quia. Enim, quae, ipsum cupiditate quod provident nihil.',	'2018-03-20 18:20:59',	'2018-03-20 18:20:59',	'internet-neutrality.jpeg',	1),
(10,	'Titre Lorem',	'Lede Lorem ',	'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum atque, mollitia obcaecati alias nam vitae dolore consectetur quos nostrum sit tempore excepturi deserunt omnis. Ipsa labore ratione ea deserunt corporis!',	'2018-03-22 18:09:52',	'2018-03-22 18:09:52',	'infos-internet.jpg',	1);

DROP TABLE IF EXISTS `post_tag`;
CREATE TABLE `post_tag` (
  `id_post` int(11) NOT NULL,
  `id_tag` int(11) NOT NULL,
  KEY `id_post` (`id_post`),
  KEY `id_tag` (`id_tag`),
  CONSTRAINT `post_tag_ibfk_1` FOREIGN KEY (`id_post`) REFERENCES `post` (`id`),
  CONSTRAINT `post_tag_ibfk_2` FOREIGN KEY (`id_tag`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` char(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tag` (`id`, `label`) VALUES
(1,	'a');

DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `type` (`id`, `type`) VALUES
(1,	'admin'),
(2,	'member');

-- 2018-03-29 09:25:31
